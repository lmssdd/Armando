# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/100mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img100.png"
 ALT="$ 100 \mu s$">|; 

$key = q/140mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img102.png"
 ALT="$ 140 \mu s$">|; 

$key = q/62K;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$ 62 K$">|; 

$key = q/displaystylef({bfx})=int_Omegaf({bfx'})W({bfx}-{bfx'},h)dOmega;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="243" HEIGHT="56" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$\displaystyle f({\bf x}) = \int_\Omega f({\bf x'})W({\bf x} - {\bf x'}, h) d\Omega$">|; 

$key = q/gamma=0.654066;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="103" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img58.png"
 ALT="$ \gamma = 0.654066$">|; 

$key = q/20Hz;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="$ 20Hz$">|; 

$key = q/1.5mslashs;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="59" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img82.png"
 ALT="$ 1.5m/s$">|; 

$key = q/f=20Hz;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="$ f=20 Hz$">|; 

$key = q/W;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$ W$">|; 

$key = q/4mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img77.png"
 ALT="$ 4mm$">|; 

$key = q/delta=6.72606;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="$ \delta = 6.72606$">|; 

$key = q/displaystylemu=frac{rho-rho_0}{rho_0};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="89" HEIGHT="54" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="$\displaystyle \mu = \frac{\rho - \rho_0}{\rho_0}$">|; 

$key = q/150kPa;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$ 150kPa$">|; 

$key = q/n_p;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="$ n_p$">|; 

$key = q/1.6mslashs;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="59" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$ 1.6m/s$">|; 

$key = q/rho_j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$ \rho_j$">|; 

$key = q/rho_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$ \rho_i$">|; 

$key = q/displaystylenablaf_i=sum_jm_jfrac{f_j}{rho_j}nablaW_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="169" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="$\displaystyle \nabla f_i = \sum_j m_j \frac{f_j}{\rho_j} \nabla W_{ij}$">|; 

$key = q/110mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="$ 110mm$">|; 

$key = q/85K;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$ 85 K$">|; 

$key = q/displaystylef_i=sum_jm_jfrac{f_j}{rho_j}W_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="140" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$\displaystyle f_i = \sum_j m_j \frac{f_j}{\rho_j}W_{ij}$">|; 

$key = q/9kJslashkg;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$ 9 kJ/kg$">|; 

$key = q/W_{ij}=W({bfx}-{bfx'},h);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$ W_{ij} = W({\bf x} - {\bf x'}, h)$">|; 

$key = q/50000;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img94.png"
 ALT="$ 50000$">|; 

$key = q/Gamma_0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img74.png"
 ALT="$ \Gamma_0$">|; 

$key = q/2.66;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img76.png"
 ALT="$ 2.66$">|; 

$key = q/10^{-4};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="$ 10^{-4}$">|; 

$key = q/m_j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$ m_j$">|; 

$key = q/220mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="$ 220 mm$">|; 

$key = q/60mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img98.png"
 ALT="$ 60 \mu s$">|; 

$key = q/Gamma;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img89.png"
 ALT="$ \Gamma$">|; 

$key = q/20mslashs;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img81.png"
 ALT="$ 20m/s$">|; 

$key = q/v_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$ v_i$">|; 

$key = q/12.5kJslashkg;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="83" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$ 12.5 kJ/kg$">|; 

$key = q/I=2mA;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="$ I=2 mA$">|; 

$key = q/1ms;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="$ 1ms$">|; 

$key = q/10mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$ 10 \mu s$">|; 

$key = q/displaystyleK_s=rhoc^2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="73" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="$\displaystyle K_s = \rho c^2$">|; 

$key = q/{displaymath}{split}e_p(x_1,x_2,x_3)&=f(x_1,x_2)g(x_3)f(x_1,x_2)&=e^{-frac{1}{2}}left(1-e^{-gamma-frac{x_3}{delta}}right){split}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="275" HEIGHT="111" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="\begin{displaymath}\begin{split}e_p(x_1, x_2, x_3) &amp; = f(x_1, x_2) g(x_3)  f(x...
...} \left( 1 - e^{-\gamma -\frac{x_3}{\delta}}\right) \end{split}\end{displaymath}">|; 

$key = q/alpha=127.410^{-6}cdotK^{-1};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img70.png"
 ALT="$ \alpha = 127.4 10^{-6} \cdot K^{-1}$">|; 

$key = q/8ms;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img91.png"
 ALT="$ 8ms$">|; 

$key = q/20mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img96.png"
 ALT="$ 20 \mu s$">|; 

$key = q/100;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img87.png"
 ALT="$ 100$">|; 

$key = q/u_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$ u_i$">|; 

$key = q/31.3GPa;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="72" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img75.png"
 ALT="$ 31.3GPa$">|; 

$key = q/c_p;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img71.png"
 ALT="$ c_p$">|; 

$key = q/displaystyle{bff}_i=sum_jc_j^2h^2W_{ij}frac{{bfx}_i-{bfx}_j}{|{bfx}_i-{bfx}_j|};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="$\displaystyle {\bf f}_i = \sum_j c_j^2 h^2 W_{ij} \frac{{\bf x}_i - {\bf x}_j}{\vert{\bf x}_i - {\bf x}_j\vert}$">|; 

$key = q/f({bfx});MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="$ f({\bf x})$">|; 

$key = q/alpha=0.00130948;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="122" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="$ \alpha = 0.00130948$">|; 

$key = q/235mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="$ 235mm$">|; 

$key = q/n_p^2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="$ n_p^2$">|; 

$key = q/Omega;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$ \Omega$">|; 

$key = q/500MW;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="68" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img105.png"
 ALT="$ 500MW$">|; 

$key = q/x_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$ x_i$">|; 

$key = q/displaystyleGamma_0=frac{alphaK_s}{rho_0c_p};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="83" HEIGHT="56" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="$\displaystyle \Gamma_0 = \frac{\alpha K_s}{\rho_0 c_p}$">|; 

$key = q/[mslashs];MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$ [m/s]$">|; 

$key = q/600mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="$ 600 mm$">|; 

$key = q/10^{-6};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$ 10^{-6}$">|; 

$key = q/W=2500MeV;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="122" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="$ W=2500MeV$">|; 

$key = q/displaystyledot{bfv}_i=sum_jm_jleft(frac{p_i}{rho_i^2}+frac{p_j}{rho_j^2}right)nablaW_{ij}+{bfg}_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="269" HEIGHT="71" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="$\displaystyle \dot {\bf v}_i = \sum_j m_j \left(\frac{p_i}{\rho_i^2}+\frac{p_j}{\rho_j^2} \right) \nabla W_{ij} + {\bf g}_i$">|; 

$key = q/1740mslashs;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img69.png"
 ALT="$ 1740m/s$">|; 

$key = q/m_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$ m_i$">|; 

$key = q/1m;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="$ 1m$">|; 

$key = q/i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$ i$">|; 

$key = q/160mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img103.png"
 ALT="$ 160 \mu s$">|; 

$key = q/c_j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="$ c_j$">|; 

$key = q/50;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="$ 50$">|; 

$key = q/10;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$ 10$">|; 

$key = q/2s;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img85.png"
 ALT="$ 2s$">|; 

$key = q/2mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img92.png"
 ALT="$ 2 \mu s$">|; 

$key = q/3mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img79.png"
 ALT="$ 3 mm$">|; 

$key = q/K_s;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="26" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img73.png"
 ALT="$ K_s$">|; 

$key = q/Q=UI=5MW;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="134" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="$ Q = UI = 5 MW$">|; 

$key = q/{displaymath}{split}dotu_i=&frac{1}{2}sum_jm_jleft(frac{p_i}{rho_i^2}+frac{p_j}{({bfv}_i-{bfv}_j)cdot&cdotnablaW_{ij}+q_i{split}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="268" HEIGHT="90" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="\begin{displaymath}\begin{split}\dot u_i = &amp; \frac{1}{2} \sum_j m_j \left(\frac{...
...i - {\bf v}_j) \cdot  &amp; \cdot \nabla W_{ij} + q_i \end{split}\end{displaymath}">|; 

$key = q/2m;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img84.png"
 ALT="$ 2m$">|; 

$key = q/beta=15.5814;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="95" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="$ \beta = 15.5814$">|; 

$key = q/h;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$ h$">|; 

$key = q/146JslashkgK;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img72.png"
 ALT="$ 146J/kgK$">|; 

$key = q/17.4mslashs;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img88.png"
 ALT="$ 17.4 m/s$">|; 

$key = q/80mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img99.png"
 ALT="$ 80 \mu s$">|; 

$key = q/100ms;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img93.png"
 ALT="$ 100ms$">|; 

$key = q/120mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img101.png"
 ALT="$ 120 \mu s$">|; 

$key = q/[Jslashkg];MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$ [J/kg]$">|; 

$key = q/i=1ldotsn_p;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$ i = 1 \ldots n_p$">|; 

$key = q/2ms;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img95.png"
 ALT="$ 2ms$">|; 

$key = q/40mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img97.png"
 ALT="$ 40 \mu s$">|; 

$key = q/20bar;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img104.png"
 ALT="$ 20bar$">|; 

$key = q/displaystyledotrho_i=sum_jm_j({bfv}_i-{bfv}_j)cdotnablaW_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="216" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="$\displaystyle \dot \rho_i = \sum_j m_j ({\bf v}_i - {\bf v}_j) \cdot \nabla W_{ij}$">|; 

$key = q/1GB;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="41" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img80.png"
 ALT="$ 1GB$">|; 

$key = q/cm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="$ cm$">|; 

$key = q/f_i={hatf}({bfx}_i);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$ f_i = {\hat f}({\bf x}_i)$">|; 

$key = q/75^circ;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="$ 75^\circ$">|; 

$key = q/j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$ j$">|; 

$key = q/10338kgslashm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img68.png"
 ALT="$ 10338kg/m$">|; 

$key = q/h=4.8mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img78.png"
 ALT="$ h = 4.8mm$">|; 

$key = q/4000;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img90.png"
 ALT="$ 4000$">|; 

$key = q/bf{f}_i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="$ \bf {f}_i$">|; 

$key = q/2mslashs;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img83.png"
 ALT="$ 2m/s$">|; 

$key = q/85mm;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$ 85mm$">|; 

$key = q/displaystylep=p_0+K_smu+Gamma_0rho_0u;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="173" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="$\displaystyle p = p_0 + K_s \mu + \Gamma_0 \rho_0 u$">|; 

$key = q/{displaymath}{split}x_1&=zx_2&=yx_3&=x-yslashtg(75^circ){split}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="142" HEIGHT="81" BORDER="0"
 SRC="|."$dir".q|img62.png"
 ALT="\begin{displaymath}\begin{split}x_1 &amp; = z  x_2 &amp; = y  x_3 &amp; = x - y / tg(75^\circ) \end{split}\end{displaymath}">|; 

$key = q/2.3mus;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img86.png"
 ALT="$ 2.3 \mu s$">|; 

$key = q/573K;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img67.png"
 ALT="$ 573K$">|; 

$key = q/displaystylep_i=EOS(rho_i,u_i);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="132" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="$\displaystyle p_i=EOS(\rho_i, u_i)$">|; 

$key = q/2.3MW;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="$ 2.3MW$">|; 

1;

